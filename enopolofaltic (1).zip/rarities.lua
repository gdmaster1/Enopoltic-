SMODS.Rarity {
    key = "epic",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.02,
    badge_colour = HEX('f8e71c'),
    loc_txt = {
        name = "Epic"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "legendary",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.005,
    badge_colour = HEX('6A7A8B'),
    loc_txt = {
        name = "Legendary?"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "joke_r",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.075,
    badge_colour = HEX('223d5a'),
    loc_txt = {
        name = "Joke (r)"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "unique",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.1,
    badge_colour = HEX('9013fe'),
    loc_txt = {
        name = "Unique"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "mythic",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.008,
    badge_colour = HEX('6A7A8B'),
    loc_txt = {
        name = "Mythic"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "mythic_2",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.003,
    badge_colour = HEX('417505'),
    loc_txt = {
        name = "Mythic 2"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "mythicplus",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.002,
    badge_colour = HEX('7ed321'),
    loc_txt = {
        name = "Mythicplus"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}