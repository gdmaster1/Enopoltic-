SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomConsumables", 
    path = "CustomConsumables.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomEnhancements", 
    path = "CustomEnhancements.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomSeals", 
    path = "CustomSeals.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
}):register()

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end

local jokerIndexList = {14,7,32,28,45,29,52,36,49,12,51,23,19,31,44,27,25,26,9,37,4,24,15,50,43,16,6,13,17,11,38,22,48,20,33,41,47,42,18,34,39,5,3,10,1,2,21,8,30,35,46,40}

local function load_jokers_folder()
    local mod_path = SMODS.current_mod.path
    local jokers_path = mod_path .. "/jokers"
    local files = NFS.getDirectoryItemsInfo(jokers_path)
    for i = 1, #jokerIndexList do
        local file_name = files[jokerIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("jokers/" .. file_name))()
        end
    end
end


local consumableIndexList = {7,6,4,2,3,1,5}

local function load_consumables_folder()
    local mod_path = SMODS.current_mod.path
    local consumables_path = mod_path .. "/consumables"
    local files = NFS.getDirectoryItemsInfo(consumables_path)
    local set_file_number = #files + 1
    for i = 1, #files do
        if files[i].name == "sets.lua" then
            assert(SMODS.load_file("consumables/sets.lua"))()
            set_file_number = i
        end
    end    
    for i = 1, #consumableIndexList do
        local j = consumableIndexList[i]
        if j >= set_file_number then 
            j = j + 1
        end
        local file_name = files[j].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("consumables/" .. file_name))()
        end
    end
end


local enhancementIndexList = {1}

local function load_enhancements_folder()
    local mod_path = SMODS.current_mod.path
    local enhancements_path = mod_path .. "/enhancements"
    local files = NFS.getDirectoryItemsInfo(enhancements_path)
    for i = 1, #enhancementIndexList do
        local file_name = files[enhancementIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("enhancements/" .. file_name))()
        end
    end
end


local sealIndexList = {1}

local function load_seals_folder()
    local mod_path = SMODS.current_mod.path
    local seals_path = mod_path .. "/seals"
    local files = NFS.getDirectoryItemsInfo(seals_path)
    for i = 1, #sealIndexList do
        local file_name = files[sealIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("seals/" .. file_name))()
        end
    end
end


local editionIndexList = {1}

local function load_editions_folder()
    local mod_path = SMODS.current_mod.path
    local editions_path = mod_path .. "/editions"
    local files = NFS.getDirectoryItemsInfo(editions_path)
    for i = 1, #editionIndexList do
        local file_name = files[editionIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("editions/" .. file_name))()
        end
    end
end


local deckIndexList = {1}

local function load_decks_folder()
    local mod_path = SMODS.current_mod.path
    local decks_path = mod_path .. "/decks"
    local files = NFS.getDirectoryItemsInfo(decks_path)
    for i = 1, #deckIndexList do
        local file_name = files[deckIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("decks/" .. file_name))()
        end
    end
end

local function load_rarities_file()
    local mod_path = SMODS.current_mod.path
    assert(SMODS.load_file("rarities.lua"))()
end

load_rarities_file()

local function load_boosters_file()
    local mod_path = SMODS.current_mod.path
    assert(SMODS.load_file("boosters.lua"))()
end

load_boosters_file()
load_jokers_folder()
load_consumables_folder()
load_enhancements_folder()
load_seals_folder()
load_editions_folder()
load_decks_folder()
SMODS.ObjectType({
    key = "enopolof_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "enopolof_baladnes_jokers",
    cards = {
        ["j_enopolof_antefreezer"] = true,
        ["j_enopolof_asimpleone"] = true,
        ["j_enopolof_awiseinvestment"] = true,
        ["j_enopolof_bank"] = true,
        ["j_enopolof_benten"] = true,
        ["j_enopolof_calculator"] = true,
        ["j_enopolof_cardbooster"] = true,
        ["j_enopolof_carinick"] = true,
        ["j_enopolof_chilppy"] = true,
        ["j_enopolof_clown"] = true,
        ["j_enopolof_deckbuilding"] = true,
        ["j_enopolof_edwardexponent"] = true,
        ["j_enopolof_extraoddtod"] = true,
        ["j_enopolof_gamblingforfree"] = true,
        ["j_enopolof_geometrydash"] = true,
        ["j_enopolof_greedyjokerofmult"] = true,
        ["j_enopolof_infinityandbeyond"] = true,
        ["j_enopolof_inhumanengineering"] = true,
        ["j_enopolof_insertcashorselectpaymenttype"] = true,
        ["j_enopolof_inversejokerstencil"] = true,
        ["j_enopolof_inversesjokerstencilsynergyijss"] = true,
        ["j_enopolof_isthisthecrispiestjoker"] = true,
        ["j_enopolof_jokerpremium"] = true,
        ["j_enopolof_kingsbling"] = true,
        ["j_enopolof_letsgogambling"] = true,
        ["j_enopolof_mold"] = true,
        ["j_enopolof_moneyspread"] = true,
        ["j_enopolof_oopsallstraightflushes"] = true,
        ["j_enopolof_permanentdiscount"] = true,
        ["j_enopolof_poker"] = true,
        ["j_enopolof_rna"] = true,
        ["j_enopolof_rofflewilllovethisone"] = true,
        ["j_enopolof_slowscaling"] = true,
        ["j_enopolof_specificcardcreationjoker"] = true,
        ["j_enopolof_themarketplace"] = true,
        ["j_enopolof_thenewjoker"] = true,
        ["j_enopolof_whereallthechipsat"] = true
    },
})

SMODS.ObjectType({
    key = "enopolof_enopolti_jokers",
    cards = {
        ["j_enopolof_antiprime"] = true,
        ["j_enopolof_bubblyjoker"] = true,
        ["j_enopolof_hydrogenbomb"] = true,
        ["j_enopolof_jokerpoker"] = true,
        ["j_enopolof_massinvestment"] = true,
        ["j_enopolof_slipperysteps"] = true
    },
})

SMODS.ObjectType({
    key = "enopolof_mycustom_jokers",
    cards = {
        ["j_enopolof_bigeyedjimbo"] = true,
        ["j_enopolof_colonthree3"] = true,
        ["j_enopolof_jbox360"] = true,
        ["j_enopolof_jkr"] = true,
        ["j_enopolof_jokicon"] = true,
        ["j_enopolof_rowofteeth"] = true,
        ["j_enopolof_youwillplaythenewdeck"] = true
    },
})

SMODS.ObjectType({
    key = "enopolof_enopolof_jokers",
    cards = {
        ["j_enopolof_paintball"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end