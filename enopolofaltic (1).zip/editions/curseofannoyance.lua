
SMODS.Shader({ key = 'laminated', path = 'laminated.fs' })

SMODS.Edition {
    key = 'curseofannoyance',
    shader = 'laminated',
    config = {
        extra = {
            repetitions = 1
        }
    },
    in_shop = true,
    weight = 0.125,
    extra_cost = 20,
    apply_to_float = false,
    badge_colour = HEX('272239'),
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Curse Of Annoyance',
        label = 'Curse Of Annoyance',
        text = {
            [1] = 'Gives 1-3 Negative Perishable Jokers If Card Discarded Only if Boss Blind is The House'
        }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if context.discard and context.other_card == card and to_big(G.GAME.blind.config.blind.key) == to_big("bl_house") then
            for i = 1, card.ability.extra.repetitions do
                local created_joker = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        local joker_card = SMODS.add_card({ set = 'Joker' })
                        if joker_card then
                            joker_card:set_edition("e_negative", true)
                            joker_card:add_sticker('perishable', true)
                        end
                        
                        return true
                    end
                }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
            end
        end
    end
}