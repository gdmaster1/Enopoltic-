
SMODS.Seal {
    key = 'pain',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('000000'),
    loc_txt = {
        name = 'pain',
        label = 'pain',
        text = {
            [1] = 'does nothing'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false
}