
SMODS.Booster {
    key = '_foil_jokers',
    loc_txt = {
        name = "50 Foil Jokers",
        text = {
            [1] = '50 FOIL JOKERS FOR A SATISFACTORY PRICE'
        },
        group_name = "mycustom_boosters"
    },
    config = { extra = 50, choose = 5 },
    cost = 200,
    weight = 5,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    group_key = "mycustom_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "Joker",
            edition = "e_foil",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "enopolof__foil_jokers"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("c62f2f"))
        ease_background_colour({ new_colour = HEX('c62f2f'), special_colour = HEX("c91616"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    
    
    SMODS.Booster {
        key = 'newboosterpack',
        loc_txt = {
            name = "New Booster Pack",
            text = {
                [1] = 'A {C:purple}custom{} booster pack with {C:blue}unique{} cards.'
            },
            group_name = "enopolti_boosters"
        },
        config = { extra = 3, choose = 1 },
        atlas = "CustomBoosters",
        pos = { x = 1, y = 0 },
        group_key = "enopolti_boosters",
        discovered = true,
        loc_vars = function(self, info_queue, card)
            local cfg = (card and card.ability) or self.config
            return {
                vars = { cfg.choose, cfg.extra }
            }
        end,
        create_card = function(self, card, i)
            return {
                set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true
            }
        end,
        particles = function(self)
            -- No particles for joker packs
            end,
        }
        