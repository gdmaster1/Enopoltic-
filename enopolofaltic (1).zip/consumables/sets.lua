SMODS.ConsumableType {
    key = 'mayhem_cards',
    primary_colour = HEX('666666'),
    secondary_colour = HEX('666666'),
    collection_rows = { 4, 5 },
    shop_rate = 3,
    cards = {
        ['c_enopolof_fullreset'] = true,
        ['c_enopolof_cyborg'] = true,
        ['c_enopolof_finishline'] = true,
        ['c_enopolof_anteintrest'] = true
    },
    loc_txt = {
        name = "Mayhem Cards",
        collection = "Mayhem Cards Cards",
    }
}