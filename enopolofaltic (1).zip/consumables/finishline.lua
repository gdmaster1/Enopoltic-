
SMODS.Consumable {
    key = 'finishline',
    set = 'mayhem_cards',
    pos = { x = 4, y = 0 },
    loc_txt = {
        name = 'Finish line',
        text = {
            [1] = 'Sets Winning Ante To {C:red}-1{} antes less'
        }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
                card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "-"..tostring(1).." Ante to Win", colour = G.C.RED})
                local ante = G.GAME.win_ante - 1
                local int_part, frac_part = math.modf(ante)
                local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
                G.GAME.win_ante = rounded
                return true
            end
        }))
        delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}