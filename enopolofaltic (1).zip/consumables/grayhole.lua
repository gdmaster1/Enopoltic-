
SMODS.Consumable {
    key = 'grayhole',
    set = 'Planet',
    pos = { x = 6, y = 0 },
    config = { 
        extra = {
            odds = 2,
            odds = 2   
        } 
    },
    loc_txt = {
        name = 'Gray Hole',
        text = {
            [1] = '1/2 Chance to Level down most played hand',
            [2] = '1/2 chance to level up most played hand twice',
            [3] = '(both can trigger at the same time)'
        }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        if SMODS.pseudorandom_probability(card, 'group_0_d4e63ad1', 1, card.ability.extra.odds, 'j_enopolof_grayhole', false) then
            SMODS.calculate_effect({
                local temp_played = 0
                local temp_order = math.huge
                local target_hand = 'High Card'
                for hand, value in pairs(G.GAME.hands) do 
                    if value.played > temp_played and value.visible then
                        temp_played = value.played
                        temp_order = value.order
                        target_hand = hand
                    elseif value.played == temp_played and value.visible then
                        if value.order < temp_order then
                            temp_order = value.order
                            target_hand = hand
                        end
                    end
                end
            )
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    play_sound('tarot1')
                    card:juice_up(0.8, 0.5)
                    G.TAROT_INTERRUPT_PULSE = true
                    return true
                end
            }))
            update_hand_text({ delay = 0 }, { mult = '+', StatusText = true })
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.9,
                func = function()
                    play_sound('tarot1')
                    card:juice_up(0.8, 0.5)
                    return true
                end
            }))
            update_hand_text({ delay = 0 }, { chips = '+', StatusText = true })
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.9,
                func = function()
                    play_sound('tarot1')
                    card:juice_up(0.8, 0.5)
                    G.TAROT_INTERRUPT_PULSE = nil
                    return true
                end
            }))
            update_hand_text({ sound = 'button', volume = 0.7, pitch = 0.9, delay = 0 }, { level = '+'..tostring(-2) })
            delay(1.3)
            level_up_hand(card, "Pair", true, -2)
            update_hand_text({sound = 'button', volume = 0.7, pitch = 1.1, delay = 0}, 
                {handname=localize('Pair', 'poker_hands'), 
                    chips = G.GAME.hands['Pair'].chips, 
                    mult = G.GAME.hands['Pair'].mult, 
                level=G.GAME.hands['Pair'].level})    
                delay(1.3)
            __PRE_RETURN_CODE_END__}, card)
        end
        if SMODS.pseudorandom_probability(card, 'group_0_a6b5b7f7', 1, card.ability.extra.odds, 'j_enopolof_grayhole', false) then
            SMODS.calculate_effect({
                local temp_played = 0
                local temp_order = math.huge
                local target_hand = 'High Card'
                for hand, value in pairs(G.GAME.hands) do 
                    if value.played > temp_played and value.visible then
                        temp_played = value.played
                        temp_order = value.order
                        target_hand = hand
                    elseif value.played == temp_played and value.visible then
                        if value.order < temp_order then
                            temp_order = value.order
                            target_hand = hand
                        end
                    end
                end
            )
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    play_sound('tarot1')
                    card:juice_up(0.8, 0.5)
                    G.TAROT_INTERRUPT_PULSE = true
                    return true
                end
            }))
            update_hand_text({ delay = 0 }, { mult = '+', StatusText = true })
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.9,
                func = function()
                    play_sound('tarot1')
                    card:juice_up(0.8, 0.5)
                    return true
                end
            }))
            update_hand_text({ delay = 0 }, { chips = '+', StatusText = true })
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.9,
                func = function()
                    play_sound('tarot1')
                    card:juice_up(0.8, 0.5)
                    G.TAROT_INTERRUPT_PULSE = nil
                    return true
                end
            }))
            update_hand_text({ sound = 'button', volume = 0.7, pitch = 0.9, delay = 0 }, { level = '+'..tostring(2) })
            delay(1.3)
            level_up_hand(card, "Pair", true, 2)
            update_hand_text({sound = 'button', volume = 0.7, pitch = 1.1, delay = 0}, 
                {handname=localize('Pair', 'poker_hands'), 
                    chips = G.GAME.hands['Pair'].chips, 
                    mult = G.GAME.hands['Pair'].mult, 
                level=G.GAME.hands['Pair'].level})    
                delay(1.3)
            __PRE_RETURN_CODE_END__}, card)
        end
    end,
    can_use = function(self, card)
        return true
    end
}