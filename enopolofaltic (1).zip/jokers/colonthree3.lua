
SMODS.Joker{ --Colon Three [:3]
    key = "colonthree3",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Colon Three [:3]',
        ['text'] = {
            [1] = 'If {X:,C:white}High Card{} is played and K, Q or J is all card ranks in played hand, give {X:chips,C:white}+300{} Chips and {X:red,C:white}+20{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = "enopolof_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (context.scoring_name == "High Card" and (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if playing_card:is_face() then
                        count = count + 1
                    end
                end
                return count == #context.scoring_hand
            end)()) then
            end
        end
    end
}