
SMODS.Joker{ --Calculator
    key = "calculator",
    config = {
        extra = {
            blind_size0 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Calculator',
        ['text'] = {
            [1] = 'Blind Requirement Is Divided By 1.5 Every Hand Played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    set_ability = function(self, card, initial)
        card:set_edition("e_holo", true)
    end,
    
    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            return {
                
                func = function()
                    if G.GAME.blind.in_blind then
                        
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "/"..tostring(1.5).." Blind Size", colour = G.C.GREEN})
                        G.GAME.blind.chips = G.GAME.blind.chips / 1.5
                        G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                        G.HUD_blind:recalculate()
                        return true
                    end
                end
            }
        end
    end
}