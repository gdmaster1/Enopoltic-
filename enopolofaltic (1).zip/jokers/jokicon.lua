
SMODS.Joker{ --Jokicon
    key = "jokicon",
    config = {
        extra = {
            totaljokerslots = 0,
            money÷5 = 0,
            levels0 = 4,
            xchips0 = 4,
            xmult0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Jokicon',
        ['text'] = {
            [1] = '{C:attention}X4{} Of most main stats (Money (X4 Intrest), Mult, Chips) {C:attention}X4{} JOKER SLOTS'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 50,
    rarity = "enopolof_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_mycustom_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {((G.jokers and G.jokers.config.card_limit or 0 or 0)) * 3, ((math.floor(lenient_bignum(G.GAME.dollars / 5)) or 0)) * 3}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end, 
    
    calc_dollar_bonus = function(card)
        local blind_reward = 0
        blind_reward = blind_reward + math.max((math.floor(lenient_bignum(G.GAME.dollars / 5))) * 3, 0)
        if blind_reward > 0 then
            return blind_reward
        end
    end,
    
    calculate = function(self, card, context)
        if context.buying_card and context.card.config.center.key == self.key and context.cardarea == G.jokers  then
            local temp_played = 0
            local temp_order = math.huge
            local target_hand
            for hand, value in pairs(G.GAME.hands) do 
                if value.played > temp_played and value.visible then
                    temp_played = value.played
                    temp_order = value.order
                    target_hand = hand
                elseif value.played == temp_played and value.visible then
                    if value.order < temp_order then
                        temp_order = value.order
                        target_hand = hand
                    end
                end
            end
            
            level_up_hand(card, target_hand, true, 4)
            return {
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring((G.jokers and G.jokers.config.card_limit or 0) * 3).." Joker Slot", colour = G.C.DARK_EDITION})
                    G.jokers.config.card_limit = G.jokers.config.card_limit + (G.jokers and G.jokers.config.card_limit or 0) * 3
                    return true
                end,
                extra = {
                    message = "+4 Most hand Played Level",
                    colour = G.C.RED
                }
            }
        end
        if context.selling_self  then
            return {
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring((G.jokers and G.jokers.config.card_limit or 0) * 0.75).." Joker Slot", colour = G.C.RED})
                    G.jokers.config.card_limit = math.max(1, G.jokers.config.card_limit - (G.jokers and G.jokers.config.card_limit or 0) * 0.75)
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                x_chips = 4,
                extra = {
                    Xmult = 4
                }
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
        end
    end
}