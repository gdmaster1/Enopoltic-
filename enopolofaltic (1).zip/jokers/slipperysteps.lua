
SMODS.Joker{ --Slippery Steps
    key = "slipperysteps",
    config = {
        extra = {
            odds = 2,
            chips0 = 10,
            mult0 = 10,
            odds2 = 5,
            xchips0 = 2,
            odds3 = 15,
            xchips = 3,
            xmult0 = 3,
            odds4 = 20,
            xchips2 = 0,
            odds5 = 25,
            xchips3 = 0,
            xmult = 0,
            odds6 = 40,
            dollars0 = 20,
            odds7 = 80,
            dollars = 50,
            odds8 = 1000
        }
    },
    loc_txt = {
        ['name'] = 'Slippery Steps',
        ['text'] = {
            [1] = '1/2 chance for +10 Mult and chips',
            [2] = '1/5 chance to double Chips',
            [3] = '1/15 chance to triple Mult and Chips',
            [4] = '1/20 chance to set Chips to 0',
            [5] = '1/25 to set Chips and Mult to 0',
            [6] = '1/40 chance to change money by -20',
            [7] = '1/80 chance to gain 50$',
            [8] = '1/1000 to instantly lose',
            [9] = '',
            [10] = '(Multiple can be triggered in one hand)',
            [11] = '(Probablity Changing Jokers Do Not Work)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_enopolti_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_enopolof_slipperysteps')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_enopolof_slipperysteps')
        local new_numerator3, new_denominator3 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds3, 'j_enopolof_slipperysteps')
        local new_numerator4, new_denominator4 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds4, 'j_enopolof_slipperysteps')
        local new_numerator5, new_denominator5 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds5, 'j_enopolof_slipperysteps')
        local new_numerator6, new_denominator6 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds6, 'j_enopolof_slipperysteps')
        local new_numerator7, new_denominator7 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds7, 'j_enopolof_slipperysteps')
        local new_numerator8, new_denominator8 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds8, 'j_enopolof_slipperysteps')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2, new_numerator3, new_denominator3, new_numerator4, new_denominator4, new_numerator5, new_denominator5, new_numerator6, new_denominator6, new_numerator7, new_denominator7, new_numerator8, new_denominator8}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_5aed61a7', 1, card.ability.extra.odds, 'j_enopolof_slipperysteps', true) then
                    SMODS.calculate_effect({chips = 10}, card)
                    SMODS.calculate_effect({mult = 10}, card)
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_570cc54f', 1, card.ability.extra.odds2, 'j_enopolof_slipperysteps', true) then
                    SMODS.calculate_effect({x_chips = 2}, card)
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_2553bd96', 1, card.ability.extra.odds3, 'j_enopolof_slipperysteps', true) then
                    SMODS.calculate_effect({x_chips = 3}, card)
                    SMODS.calculate_effect({Xmult = 3}, card)
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_9ffc5047', 1, card.ability.extra.odds4, 'j_enopolof_slipperysteps', true) then
                    SMODS.calculate_effect({x_chips = 0}, card)
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_81067a4e', 1, card.ability.extra.odds5, 'j_enopolof_slipperysteps', true) then
                    SMODS.calculate_effect({x_chips = 0}, card)
                    SMODS.calculate_effect({Xmult = 0}, card)
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_54b7bf69', 1, card.ability.extra.odds6, 'j_enopolof_slipperysteps', true) then
                    SMODS.calculate_effect({
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars - 20
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(20), colour = G.C.MONEY})
                            return true
                        end}, card)
                    end
                elseif true then
                    if SMODS.pseudorandom_probability(card, 'group_0_9ac8fa9d', 1, card.ability.extra.odds7, 'j_enopolof_slipperysteps', true) then
                        SMODS.calculate_effect({
                            func = function()
                                
                                local current_dollars = G.GAME.dollars
                                local target_dollars = G.GAME.dollars + 50
                                local dollar_value = target_dollars - current_dollars
                                ease_dollars(dollar_value)
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(50), colour = G.C.MONEY})
                                return true
                            end}, card)
                        end
                    elseif true then
                        if SMODS.pseudorandom_probability(card, 'group_0_7acf5123', 1, card.ability.extra.odds8, 'j_enopolof_slipperysteps', true) then
                            SMODS.calculate_effect({func = function()
                                
                                G.E_MANAGER:add_event(Event({
                                    trigger = 'after',
                                    delay = 0.5,
                                    func = function()
                                        if G.STAGE == G.STAGES.RUN then 
                                            G.STATE = G.STATES.GAME_OVER
                                            G.STATE_COMPLETE = false
                                        end
                                    end
                                }))
                                
                                return true
                            end}, card)
                        end
                    end
                end
            end
        }