
SMODS.Joker{ --Insert Cash or Select Payment Type
    key = "insertcashorselectpaymenttype",
    config = {
        extra = {
            repetitions = 1,
            blind_size0 = 5,
            joker_slots0 = 1,
            joker_slots = 1
        }
    },
    loc_txt = {
        ['name'] = 'Insert Cash or Select Payment Type',
        ['text'] = {
            [1] = '{C:red}/25{} Blind requirement But {C:red}-1{} Joker Slot'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.first_hand_drawn  then
            if true then
                for i = 1, 1 do
                    SMODS.calculate_effect({
                        func = function()
                            if G.GAME.blind.in_blind then
                                
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(5).." Blind Size", colour = G.C.GREEN})
                                G.GAME.blind.chips = G.GAME.blind.chips * 5
                                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                                G.HUD_blind:recalculate()
                                return true
                            end
                        end}, card)
                    end
                end
            end
            if context.buying_card and context.card.config.center.key == self.key and context.cardarea == G.jokers  and not context.blueprint then
                return {
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(1).." Joker Slot", colour = G.C.RED})
                        G.jokers.config.card_limit = math.max(1, G.jokers.config.card_limit - 1)
                        return true
                    end
                }
            end
            if context.selling_self  and not context.blueprint then
                return {
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Joker Slot", colour = G.C.DARK_EDITION})
                        G.jokers.config.card_limit = G.jokers.config.card_limit + 1
                        return true
                    end
                }
            end
        end
    }