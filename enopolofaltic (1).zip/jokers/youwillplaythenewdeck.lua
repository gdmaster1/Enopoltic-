
SMODS.Joker{ --YOU WILL PLAY THE NEW DECK
    key = "youwillplaythenewdeck",
    config = {
        extra = {
            joker_slots0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'YOU WILL PLAY THE NEW DECK',
        ['text'] = {
            [1] = '{C:attention}+1{} Joker Slot If Flush Five Played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 36,
    rarity = "enopolof_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if next(context.poker_hands["Flush Five"]) then
                return {
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Joker Slot", colour = G.C.DARK_EDITION})
                        G.jokers.config.card_limit = G.jokers.config.card_limit + 1
                        return true
                    end
                }
            end
        end
    end
}