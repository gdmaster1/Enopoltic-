
SMODS.Joker{ --kings bling
    key = "kingsbling",
    config = {
        extra = {
            kingsinhand = 1
        }
    },
    loc_txt = {
        ['name'] = 'kings bling',
        ['text'] = {
            [1] = '1+(0.01xkings in hand)^Mult',
            [2] = 'really good with a {C:attention}Steel{} king deck'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
    return {vars = {card.ability.extra.kingsinhand + (((function() local count = 0; for _, card in ipairs(G.hand and G.hand.cards or {}) do if card.base.id == 13 then count = count + 1 end end; return count end)() or 0)) * 0.01}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
            e_mult = card.ability.extra.kingsinhand + ((function() local count = 0; for _, card in ipairs(G.hand and G.hand.cards or {}) do if card.base.id == 13 then count = count + 1 end end; return count end)()) * 0.01
            }
        end
    end
}