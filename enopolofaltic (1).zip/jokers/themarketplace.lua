
SMODS.Joker{ --The Marketplace
    key = "themarketplace",
    config = {
        extra = {
            MarketplaceValue = 1,
            totaljokerssold = 1,
            currentante = 0
        }
    },
    loc_txt = {
        ['name'] = 'The Marketplace',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}+X0.1{} Mult everytime a Joker has been sold in the run times by the ante',
            [2] = 'But Only Changes When Round Ends',
            [3] = 'Current Mult #1#',
            [4] = 'Jokers Sold #2#'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.MarketplaceValue, card.ability.extra.totaljokerssold + ((G.PROFILES[G.SETTINGS.profile].career_stats.c_jokers_sold or 0)) * 0.1, (G.GAME.round_resets.ante or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.MarketplaceValue
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            local MarketplaceValue_value = card.ability.extra.MarketplaceValue
            return {
                func = function()
                    card.ability.extra.MarketplaceValue = card.ability.extra.totaljokerssold + ((G.PROFILES[G.SETTINGS.profile].career_stats.c_jokers_sold or 0)) * 0.1
                    return true
                end,
                extra = {
                    func = function()
                        card.ability.extra.MarketplaceValue = (card.ability.extra.MarketplaceValue) * G.GAME.round_resets.ante
                        return true
                    end,
                    colour = G.C.MULT
                }
            }
        end
    end
}