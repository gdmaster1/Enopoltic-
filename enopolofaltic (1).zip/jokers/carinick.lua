
SMODS.Joker{ --Carinick
    key = "carinick",
    config = {
        extra = {
            Yorick2 = 0,
            YorickMult = 1,
            caniomult = 1,
            xmult2 = 2,
            xmult3 = 2,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Carinick',
        ['text'] = {
            [1] = 'The Best Joker Of All Time',
            [2] = 'COMBINES ALL 5 BASE {C:legendary}LEGENDARY{} JOKERS',
            [3] = '(chicot, perkeo, yorick, canio & triboulet)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 30,
    rarity = "enopolof_mythic_2",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Yorick2, card.ability.extra.YorickMult, card.ability.extra.caniomult, card.ability.extra.var1}}
    end,
    
    calculate = function(self, card, context)
        if context.first_hand_drawn  then
            return {
                func = function()
                    local target_cards = {}
                    for i, consumable in ipairs(G.consumeables.cards) do
                        if consumable.ability.set == "" then
                            table.insert(target_cards, consumable)
                        end
                    end
                    if #target_cards > 0  then
                        local card_to_copy = pseudorandom_element(target_cards, pseudoseed('copy_consumable'))
                        
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                local copied_card = copy_card(card_to_copy)
                                copied_card:set_edition("e_negative", true)
                                copied_card:add_to_deck()
                                G.consumeables:emplace(copied_card)
                                
                                return true
                            end
                        }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Copied Consumable!", colour = G.C.GREEN})
                    end
                    return true
                end,
                extra = {
                    func = function()
                        if G.GAME.blind and G.GAME.blind.boss and not G.GAME.blind.disabled then
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    G.GAME.blind:disable()
                                    play_sound('timpani')
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('ph_boss_disabled'), colour = G.C.GREEN})
                        end
                        return true
                    end,
                    colour = G.C.GREEN
                }
            }
        end
        if context.discard  then
            if to_big((card.ability.extra.var1 or 0)) == to_big(23) then
                return {
                    func = function()
                        card.ability.extra.Yorick2 = 0
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.YorickMult = (card.ability.extra.YorickMult) + 1
                            return true
                        end,
                        colour = G.C.GREEN
                    }
                }
            else
                return {
                    func = function()
                        card.ability.extra.Yorick2 = (card.ability.extra.Yorick2) + 1
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.YorickMult,
                extra = {
                    Xmult = card.ability.extra.caniomult
                }
            }
        end
        if context.individual and context.cardarea == G.play  then
            if (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if playing_card:get_id() == Q then
                        count = count + 1
                    end
                end
                return count == #context.scoring_hand
            end)() then
                return {
                    Xmult = 2
                }
            elseif (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if playing_card:get_id() == K then
                        count = count + 1
                    end
                end
                return count == #context.scoring_hand
            end)() then
                return {
                    Xmult = 2
                }
            end
        end
        if context.remove_playing_cards  then
            return {
                func = function()
                    card.ability.extra.caniomult = (card.ability.extra.caniomult) + 1
                    return true
                end
            }
        end
    end
}