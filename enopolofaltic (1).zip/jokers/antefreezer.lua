
SMODS.Joker{ --Ante Freezer
    key = "antefreezer",
    config = {
        extra = {
            ante_value0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Ante Freezer',
        ['text'] = {
            [1] = 'Ante no longer goes up until sold'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.ante_change  then
            return {
                
                func = function()
                    
                    local mod = -1
                    ease_ante(mod)
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
                            return true
                        end,
                    }))
                    return true
                end,
                message = "Ante -" .. 1
            }
        end
    end
}