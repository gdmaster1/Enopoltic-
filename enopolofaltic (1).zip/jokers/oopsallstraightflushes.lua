
SMODS.Joker{ --oops all straight flushes
    key = "oopsallstraightflushes",
    config = {
        extra = {
            reduction_value = '4'
        }
    },
    loc_txt = {
        ['name'] = 'oops all straight flushes',
        ['text'] = {
            [1] = 'flushes require {C:red}4 less cards{} and shortcut',
            [2] = 'for straights'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = "enopolof_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        -- Shortcut straights enabled
        -- Flush/Straight requirements reduced by 4
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        -- Shortcut straights disabled
        -- Flush/Straight requirements restored
    end
}


local smods_four_fingers_ref = SMODS.four_fingers
function SMODS.four_fingers()
    if next(SMODS.find_card("j_enopolof_oopsallstraightflushes")) then
        return 1
    end
    return smods_four_fingers_ref()
end
local smods_shortcut_ref = SMODS.shortcut
function SMODS.shortcut()
    if next(SMODS.find_card("j_enopolof_oopsallstraightflushes")) then
        return true
    end
    return smods_shortcut_ref()
end