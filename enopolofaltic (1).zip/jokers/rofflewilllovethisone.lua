
SMODS.Joker{ --Roffle will love this one
    key = "rofflewilllovethisone",
    config = {
        extra = {
            xmult0 = 3,
            xmult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Roffle will love this one',
        ['text'] = {
            [1] = 'Kings Give {X:red,C:white}X3{} Mult If Played AND {X:red,C:white}X2{} Mult If Held In HAND',
            [2] = 'WHY IS THIS NOT  {C:legendary}LEGENDARY{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = "enopolof_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if G.GAME.current_round.rankvar_card.rank == "[object Object]" and G.GAME.current_round.rankvar_card.id == "[object Object]" then
                return {
                    Xmult = 3
                }
            end
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if G.GAME.current_round.rankvar_card.rank == "[object Object]" and G.GAME.current_round.rankvar_card.id == "[object Object]" then
                return {
                    Xmult = 2
                }
            end
        end
    end
}