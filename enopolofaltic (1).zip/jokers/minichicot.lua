
SMODS.Joker{ --Mini Chicot
    key = "minichicot",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Mini Chicot',
        ['text'] = {
            [1] = 'Disabies effect 0f every {C:attention}Boss Blind {}at a {}{s:1.2}1/3 chance{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 0.5, 
        h = 95 * 0.5
    },
    cost = 14,
    rarity = "enopolof_epic",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers'
}