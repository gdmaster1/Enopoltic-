
SMODS.Joker{ --Greedy Joker of Mult
    key = "greedyjokerofmult",
    config = {
        extra = {
            money÷50 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Greedy Joker of Mult',
        ['text'] = {
            [1] = 'X (money/200) Mult',
            [2] = 'starts at 0'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "enopolof_unique",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {((math.floor(lenient_bignum(G.GAME.dollars / 50)) or 0)) * 0.25}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = (math.floor(lenient_bignum(G.GAME.dollars / 50))) * 0.25
            }
        end
    end
}