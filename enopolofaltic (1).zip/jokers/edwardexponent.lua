
SMODS.Joker{ --Edward Exponent
    key = "edwardexponent",
    config = {
        extra = {
            echips0 = 1.25,
            emult0 = 1.1
        }
    },
    loc_txt = {
        ['name'] = 'Edward Exponent',
        ['text'] = {
            [1] = '^1.25 Mult',
            [2] = '^1.1 Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                e_chips = 1.25,
                extra = {
                    e_mult = 1.1,
                    colour = G.C.DARK_EDITION
                }
            }
        end
    end
}