
SMODS.Joker{ --slow scaling
    key = "slowscaling",
    config = {
        extra = {
            c = 0,
            x = 5
        }
    },
    loc_txt = {
        ['name'] = 'slow scaling',
        ['text'] = {
            [1] = '{C:blue}+5{} Chips per round to this jokers value',
            [2] = 'increases by x1.2 every ante',
            [3] = '#1#'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.c, card.ability.extra.x}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()
                    card.ability.extra.c = (card.ability.extra.c) + card.ability.extra.x
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.c
            }
        end
        if context.ante_change  then
            return {
                func = function()
                    card.ability.extra.x = (card.ability.extra.x) * 1.3
                    return true
                end
            }
        end
    end
}