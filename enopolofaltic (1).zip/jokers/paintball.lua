
SMODS.Joker{ --Paint Ball
    key = "paintball",
    config = {
        extra = {
            blind_reward0 = 20,
            blind_reward = 20,
            blind_reward2 = 20,
            blind_reward3 = 20,
            blind_reward4 = 20
        }
    },
    loc_txt = {
        ['name'] = 'Paint Ball',
        ['text'] = {
            [1] = '{C:money}+20{} Dollars if hand size is a power of 2 every round',
            [2] = '(1,2,4,8,16)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "enopolof_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_enopolof_jokers"] = true }, 
    
    calc_dollar_bonus = function(card)
        local blind_reward = 0
        if to_big(G.hand.config.card_limit) == to_big(8) then
            blind_reward = blind_reward + math.max(20, 0)
        end
        if to_big(G.hand.config.card_limit) == to_big(4) then
            blind_reward = blind_reward + math.max(20, 0)
        end
        if to_big(G.hand.config.card_limit) == to_big(2) then
            blind_reward = blind_reward + math.max(20, 0)
        end
        if to_big(G.hand.config.card_limit) == to_big(1) then
            blind_reward = blind_reward + math.max(20, 0)
        end
        if to_big(G.hand.config.card_limit) == to_big(16) then
            blind_reward = blind_reward + math.max(20, 0)
        end
        if blind_reward > 0 then
            return blind_reward
        end
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if to_big(G.hand.config.card_limit) == to_big(8) then
            elseif to_big(G.hand.config.card_limit) == to_big(4) then
            elseif to_big(G.hand.config.card_limit) == to_big(2) then
            elseif to_big(G.hand.config.card_limit) == to_big(1) then
            elseif to_big(G.hand.config.card_limit) == to_big(16) then
            end
        end
    end
}