
SMODS.Joker{ --Inhuman Engineering
    key = "inhumanengineering",
    config = {
        extra = {
            chips0 = 100
        }
    },
    loc_txt = {
        ['name'] = 'Inhuman Engineering',
        ['text'] = {
            [1] = 'this will give +10000{s:0.65}^0.5{} Chips!!!!!!'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = 100
            }
        end
    end
}