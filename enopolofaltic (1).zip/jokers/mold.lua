
SMODS.Joker{ --(M)old
    key = "mold",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = '(M)old',
        ['text'] = {
            [1] = 'homie thought he could get away from the M jokers',
            [2] = '',
            [3] = '{X:red,C:white}X8{} Mult if hand contains pair'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 15,
    rarity = "enopolof_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true }
}