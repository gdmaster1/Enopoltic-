
SMODS.Joker{ --Ben Ten
    key = "benten",
    config = {
        extra = {
            xmult0 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Ben Ten',
        ['text'] = {
            [1] = '{C:red}X10{} Mult if atleast 5 cards are 10\'s'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 12,
    rarity = "enopolof_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
                local count = 0
                for _, playing_card in pairs(context.full_hand or {}) do
                    if playing_card:get_id() == 10 then
                        count = count + 1
                    end
                end
                return count == #context.full_hand
            end)() and to_big(#context.scoring_hand) >= to_big(5)) then
                return {
                    Xmult = 10
                }
            end
        end
    end
}