
SMODS.Joker{ --Where all the chips at
    key = "whereallthechipsat",
    config = {
        extra = {
            chips0 = 250,
            mult0 = -10
        }
    },
    loc_txt = {
        ['name'] = 'Where all the chips at',
        ['text'] = {
            [1] = '{X:red,C:white}-10 {} Mult',
            [2] = '{X:blue,C:white}+250{} Chips',
            [3] = '',
            [4] = 'A simple one.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = 250,
                extra = {
                    mult = -10
                }
            }
        end
    end
}