
SMODS.Joker{ --Mass Investment
    key = "massinvestment",
    config = {
        extra = {
            money÷25 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Mass Investment',
        ['text'] = {
            [1] = '{C:attention}+1{} hand and discard per 25$'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 12,
    rarity = "enopolof_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_enopolti_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(math.floor(lenient_bignum(G.GAME.dollars / 25)) or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(math.floor(lenient_bignum(G.GAME.dollars / 25))).." Hands", colour = G.C.GREEN})
                    
                    G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + math.floor(lenient_bignum(G.GAME.dollars / 25))
                    return true
                end
            }
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(math.floor(lenient_bignum(G.GAME.dollars / 25))).." Discards", colour = G.C.GREEN})
                    
                    G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + math.floor(lenient_bignum(G.GAME.dollars / 25))
                    return true
                end
            }
        end
    end
}