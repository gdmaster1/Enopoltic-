
SMODS.Joker{ --Row Of Teeth
    key = "rowofteeth",
    config = {
        extra = {
            dollars0 = 15
        }
    },
    loc_txt = {
        ['name'] = 'Row Of Teeth',
        ['text'] = {
            [1] = '+$15 If Straight Flush Is Played But Always Rental'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = "enopolof_unique",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_mycustom_jokers"] = true },
    
    set_ability = function(self, card, initial)
        card:add_sticker('rental', true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if next(context.poker_hands["Straight Flush"]) then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 15
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(15), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
    end
}