
SMODS.Joker{ --Extra Odd Tod
    key = "extraoddtod",
    config = {
        extra = {
            chips0 = 61,
            mult0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Extra Odd Tod',
        ['text'] = {
            [1] = '{C:blue}+63{} Chips when Odd card is played',
            [2] = 'also {X:red,C:white}+3{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = "enopolof_unique",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if (playing_card:get_id() == 14 or playing_card:get_id() == 3 or playing_card:get_id() == 5 or playing_card:get_id() == 7 or playing_card:get_id() == 9) then
                        count = count + 1
                    end
                end
                return count == #context.scoring_hand
            end)() then
                return {
                    chips = 61
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = 3
            }
        end
    end
}