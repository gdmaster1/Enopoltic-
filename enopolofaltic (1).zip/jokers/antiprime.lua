
SMODS.Joker{ --Anti prime
    key = "antiprime",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Anti prime',
        ['text'] = {
            [1] = 'All prime numbered cards when drawn get removed from deck',
            [2] = '(2, 3, 5, 7, J, K)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_enopolti_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            context.other_card.should_destroy = false
            if context.other_card:get_id() == 2 then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            elseif context.other_card:get_id() == 3 then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            elseif context.other_card:get_id() == 5 then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            elseif context.other_card:get_id() == 7 then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            elseif context.other_card:get_id() == 11 then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            elseif context.other_card:get_id() == 13 then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            end
        end
    end
}