
SMODS.Joker{ --.jkr
    key = "jkr",
    config = {
        extra = {
            chips0 = 0.1
        }
    },
    loc_txt = {
        ['name'] = '.jkr',
        ['text'] = {
            [1] = 'joker'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "enopolof_joke_r",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_mycustom_jokers"] = true },
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                chips = 0.1,
                extra = {
                    message = "Why you buy this",
                    colour = G.C.WHITE
                }
            }
        end
    end
}