
SMODS.Joker{ --Geometry dash
    key = "geometrydash",
    config = {
        extra = {
            _2sinhand = 0
        }
    },
    loc_txt = {
        ['name'] = 'Geometry dash',
        ['text'] = {
            [1] = 'Gives {C:attention}+2.2{} Mult for every 2 in hand'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
    return {vars = {(((function() local count = 0; for _, card in ipairs(G.hand and G.hand.cards or {}) do if card.base.id == 2 then count = count + 1 end end; return count end)() or 0)) * 2.2}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
            mult = ((function() local count = 0; for _, card in ipairs(G.hand and G.hand.cards or {}) do if card.base.id == 2 then count = count + 1 end end; return count end)()) * 2.2
            }
        end
    end
}