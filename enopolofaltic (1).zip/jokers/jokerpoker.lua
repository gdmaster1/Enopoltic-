
SMODS.Joker{ --JokerPoker
    key = "jokerpoker",
    config = {
        extra = {
            hand_size_increase = '12',
            joker_slots0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'JokerPoker',
        ['text'] = {
            [1] = 'Always Sets HandSize to 12 but {C:red}-2{} joker slots'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_enopolti_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.buying_card and context.card.config.center.key == self.key and context.cardarea == G.jokers  then
            return {
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(2).." Joker Slot", colour = G.C.RED})
                    G.jokers.config.card_limit = math.max(1, G.jokers.config.card_limit - 2)
                    return true
                end
            }
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        card.ability.extra.original_hand_size = G.hand.config.card_limit or 0
        local difference = 12 - G.hand.config.card_limit
        G.hand:change_size(difference)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        if card.ability.extra.original_hand_size then
            local difference = card.ability.extra.original_hand_size - G.hand.config.card_limit
            G.hand:change_size(difference)
        end
    end
}