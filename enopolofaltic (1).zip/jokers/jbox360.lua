
SMODS.Joker{ --Jbox360
    key = "jbox360",
    config = {
        extra = {
            chips0 = 360
        }
    },
    loc_txt = {
        ['name'] = 'Jbox360',
        ['text'] = {
            [1] = '{X:blue,C:white}+360{} Chips',
            [2] = '{X:red,C:white}+360{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 15,
    rarity = "enopolof_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = 360
            }
        end
    end
}