
SMODS.Joker{ --Is this the Crispiest Joker
    key = "isthisthecrispiestjoker",
    config = {
        extra = {
            money÷5 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Is this the Crispiest Joker',
        ['text'] = {
            [1] = 'Lets find out',
            [2] = 'Does Absolutely Nothing'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 2025,
    rarity = "enopolof_joke_r",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.money÷5 + ((math.floor(lenient_bignum(G.GAME.dollars / 5)) or 0)) * -1}}
    end,
    
    calculate = function(self, card, context)
        if context.buying_card and context.card.config.center.key == self.key and context.cardarea == G.jokers  then
            return {
                func = function()local my_pos = nil
                    for i = 1, #G.jokers.cards do
                        if G.jokers.cards[i] == card then
                            my_pos = i
                            break
                        end
                    end
                    local target_card = G.jokers.cards[my_pos]
                    target_card.ability.extra_value = card.ability.extra.money÷5 + (math.floor(lenient_bignum(G.GAME.dollars / 5))) * -1
                    target_card:set_cost()
                    return true
                end,
                message = "Sell Value: $"..tostring(card.ability.extra.money÷5 + (math.floor(lenient_bignum(G.GAME.dollars / 5))) * -1)
            }
        end
    end
}