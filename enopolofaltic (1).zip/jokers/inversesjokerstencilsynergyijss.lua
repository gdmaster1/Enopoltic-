
SMODS.Joker{ --Inverses Joker Stencil Synergy (IJSS)
    key = "inversesjokerstencilsynergyijss",
    config = {
        extra = {
            currentscoringmult = 0,
            xmult0 = -1,
            mult0 = 5
        }
    },
    loc_txt = {
        ['name'] = 'Inverses Joker Stencil Synergy (IJSS)',
        ['text'] = {
            [1] = 'If Mult Is Below 0, X-1 Mult',
            [2] = 'Else Gives +5 Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {mult}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(mult) < to_big(0) then
                return {
                    Xmult = -1
                }
            elseif to_big(mult) >= to_big(0) then
                return {
                    mult = 5
                }
            end
        end
    end
}