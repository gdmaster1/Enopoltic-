
SMODS.Joker{ --Deck Building
    key = "deckbuilding",
    config = {
        extra = {
            cardsindeck = 0,
            currenthandsize = 0
        }
    },
    loc_txt = {
        ['name'] = 'Deck Building',
        ['text'] = {
            [1] = '+(Handsize) Mult',
            [2] = '+(CardsInDeck) Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(#(G.deck and G.deck.cards or {}) or 0), ((G.hand and G.hand.config.card_limit or 0) or 0)}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = #(G.deck and G.deck.cards or {}),
                extra = {
                    mult = (G.hand and G.hand.config.card_limit or 0)
                }
            }
        end
    end
}