
SMODS.Joker{ --Big Eyed Jimbo
    key = "bigeyedjimbo",
    config = {
        extra = {
            chips0 = 200
        }
    },
    loc_txt = {
        ['name'] = 'Big Eyed Jimbo',
        ['text'] = {
            [1] = 'Gives{X:blue,C:white} +200.0{} Chips if 2 is played in hand'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if playing_card:get_id() == 2 then
                        count = count + 1
                    end
                end
                return count >= 1
            end)() then
                return {
                    chips = 200
                }
            end
        end
    end
}