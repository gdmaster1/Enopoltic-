
SMODS.Joker{ --poker
    key = "poker",
    config = {
        extra = {
            totaljokerslots = 0
        }
    },
    loc_txt = {
        ['name'] = 'poker',
        ['text'] = {
            [1] = '{C:attention}x2{} joker slots per ante'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 500,
    rarity = "enopolof_mythicplus",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["enopolof_baladnes_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(G.jokers and G.jokers.config.card_limit or 0 or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.ante_change  then
            return {
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(G.jokers and G.jokers.config.card_limit or 0).." Joker Slot", colour = G.C.DARK_EDITION})
                    G.jokers.config.card_limit = G.jokers.config.card_limit + G.jokers and G.jokers.config.card_limit or 0
                    return true
                end
            }
        end
    end
}